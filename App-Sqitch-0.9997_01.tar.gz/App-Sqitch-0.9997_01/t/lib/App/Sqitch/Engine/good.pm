package App::Sqitch::Engine::good;
extends 'App::Sqitch::Engine';
1;

=head1 NAME

good - Good stuff.

=head1 SYNOPSIS



=head1 DESCRIPTION



=cut

