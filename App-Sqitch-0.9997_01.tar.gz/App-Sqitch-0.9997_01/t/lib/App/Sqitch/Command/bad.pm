package App::Sqitch::Command::bad;
use Moo;
die 'LOL BADZ';
