SET client_min_messages = warning;
DROP SCHEMA IF EXISTS __myapp CASCADE;
